// ==============================
// CONTENT.JS — NapGuard Extension
// Se inyecta en cada página web.
// Muestra el overlay de descanso, pausa media, maneja movimiento.
// ==============================

// Variable para la animación de movimiento de la imagen
let animacionMovimiento = null

// Guarda los elementos media que estaban reproduciendo para reanudarlos al terminar
let mediaReproduciendo = []

// MutationObserver para detectar si YouTube reanuda el video bajo el blocker
let mediaObserver = null

// ==============================
// CREAR EL BLOCKER EN EL DOM
// Se inyecta en <html> (documentElement) en vez de <body>
// Así sobrevive a los re-renders de SPAs como YouTube (Polymer)
// que reemplazan el contenido del <body> al navegar entre páginas
// ==============================
const blocker = document.createElement('div')
blocker.id = 'ng-blocker'
blocker.innerHTML = `
	<div class="blockerLogo">Nap<span>Guard</span></div>
	<div class="tiempoDescanso" id="ngTiempo">00:00</div>
	<div class="blockerCenter">
		<img class="animalImg" id="ngAnimal" src="" alt="personaje">
	</div>
`
// Inyecta en <html> — no en <body>
document.documentElement.appendChild(blocker)

// ==============================
// AL CARGAR LA PESTAÑA / TAB DORMIDA REACTIVADA
// Verifica inmediatamente si hay descanso activo en storage.
// Cubre el caso de tabs que estaban dormidas (discarded) y se reactivaron —
// el content script corre desde cero y necesita saber el estado actual.
// ==============================
chrome.storage.local.get(
	['estado', 'personaje', 'segundosRestantes', 'configBlocker'],
	(data) => {
		if (data.estado === 'descanso') {
			activarBlocker(data.personaje, data.segundosRestantes || 300, data.configBlocker || null)
		}
	}
)

// ==============================
// ESCUCHAR MENSAJES DEL BACKGROUND
// El background manda el estado y ticks cada segundo.
// ==============================
chrome.runtime.onMessage.addListener((msg) => {
	if (msg.estado === 'descanso') {
		// Activa el blocker con personaje, tiempo y config
		activarBlocker(msg.personaje, msg.segundosDescanso || 300, msg.configBlocker || null)

	} else if (msg.estado === 'tick') {
		// El background manda el tiempo restante cada segundo
		// Solo actualizamos el número — el movimiento sigue por su cuenta
		const tiempoEl = document.getElementById('ngTiempo')
		if (tiempoEl) actualizarTiempo(tiempoEl, msg.segundos)

	} else if (msg.estado === 'inactivo') {
		desactivarBlocker()
	}
})

// ==============================
// YOUTUBE SPA — reinyección al navegar
// YouTube cambia de "página" sin recargar el DOM completo (Polymer/SPA).
// yt-navigate-finish se dispara cada vez que YouTube termina una navegación interna.
// Re-aplicamos el blocker y repausamos el nuevo video si el descanso sigue activo.
// ==============================
document.addEventListener('yt-navigate-finish', () => {
	chrome.storage.local.get(['estado', 'personaje', 'segundosRestantes', 'configBlocker'], (data) => {
		if (data.estado !== 'descanso') return

		// Asegura que el blocker siga visible tras la navegación interna
		if (!blocker.classList.contains('visible')) {
			activarBlocker(data.personaje, data.segundosRestantes || 300, data.configBlocker || null)
		} else {
			// Ya está visible — solo repausamos el nuevo video
			pausarMedia()
		}
	})
})

// ==============================
// ACTIVAR BLOCKER
// ==============================
function activarBlocker(personaje, segundos, configBlocker) {
	const animalImg = document.getElementById('ngAnimal')
	const tiempoEl  = document.getElementById('ngTiempo')

	// ── Fondo — color y opacidad desde configBlocker ───────
	if (configBlocker) {
		const hex = configBlocker.colorFondo.replace('#', '')
		const r   = parseInt(hex.substring(0, 2), 16)
		const g   = parseInt(hex.substring(2, 4), 16)
		const b   = parseInt(hex.substring(4, 6), 16)
		const op  = configBlocker.difuminado / 100
		blocker.style.background = `rgba(${r}, ${g}, ${b}, ${op})`
	} else {
		blocker.style.background = ''
	}

	// ── Imagen del personaje ────────────────────────────────
	if (!personaje) {
		animalImg.src = chrome.runtime.getURL('images/animales/gato.png')
	} else if (personaje.startsWith('http')) {
		animalImg.src = personaje
	} else {
		animalImg.src = chrome.runtime.getURL(personaje)
	}

	// ── Muestra el blocker ──────────────────────────────────
	blocker.classList.add('visible')

	// ── Tiempo inicial ──────────────────────────────────────
	actualizarTiempo(tiempoEl, segundos)

	// ── Pausa toda la media de la página ───────────────────
	pausarMedia()

	// ── MutationObserver — repausador automático ────────────
	// Vigila el DOM: si YouTube o cualquier página reanuda un video
	// mientras el blocker está activo, lo pausa de nuevo.
	iniciarObserverMedia()

	// ── Movimiento de la imagen ─────────────────────────────
	if (animacionMovimiento) {
		clearInterval(animacionMovimiento)
		animacionMovimiento = null
	}

	// Resetea posición del contenedor antes de aplicar movimiento
	const contenedor = document.querySelector('#ng-blocker .blockerCenter')
	if (contenedor) {
		contenedor.style.position  = ''
		contenedor.style.top       = ''
		contenedor.style.left      = ''
		contenedor.style.transform = ''
	}

	if (configBlocker && configBlocker.movimiento !== 'ninguno') {
		const ancho   = window.innerWidth
		const px      = (configBlocker.velocidad || 5) * 2
		let posX      = configBlocker.movimiento === 'ltr' ? -(animalImg.offsetWidth || 200) : ancho
		let direccion = configBlocker.movimiento === 'ltr' ? 1 : -1

		contenedor.style.position  = 'fixed'
		contenedor.style.top       = '50%'
		contenedor.style.transform = 'translateY(-50%)'
		contenedor.style.left      = posX + 'px'

		animacionMovimiento = setInterval(() => {
			posX += px * direccion
			const imgAncho = animalImg.offsetWidth || 200

			if (configBlocker.tipoMovimiento === 'atravesar') {
				if (posX > ancho)     posX = -imgAncho
				if (posX < -imgAncho) posX = ancho
			} else {
				if (posX + imgAncho >= ancho) { posX = ancho - imgAncho; direccion = -1 }
				if (posX <= 0)                { posX = 0;                 direccion = 1  }
			}

			contenedor.style.left     = posX + 'px'
			animalImg.style.transform = direccion > 0 ? 'scaleX(-1)' : 'scaleX(1)'
		}, 16)
	}
}

// ==============================
// DESACTIVAR BLOCKER
// ==============================
function desactivarBlocker() {
	blocker.classList.remove('visible')

	// Detiene la animación de movimiento
	if (animacionMovimiento) {
		clearInterval(animacionMovimiento)
		animacionMovimiento = null
	}

	// Desconecta el observer de media
	detenerObserverMedia()

	// Reanuda la media que estaba reproduciéndose antes del bloqueo
	reanudarMedia()

	// Resetea posición del contenedor
	const contenedor = document.querySelector('#ng-blocker .blockerCenter')
	if (contenedor) {
		contenedor.style.position  = ''
		contenedor.style.top       = ''
		contenedor.style.left      = ''
		contenedor.style.transform = ''
	}
}

// ==============================
// PAUSAR MEDIA
// Guarda qué elementos estaban reproduciéndose para reanudarlos al terminar.
// Cubre YouTube, Spotify Web, Netflix, Twitch, cualquier <video> o <audio>.
// ==============================
function pausarMedia() {
	mediaReproduciendo = []
	document.querySelectorAll('video, audio').forEach((el) => {
		if (!el.paused) {
			mediaReproduciendo.push(el)
			el.pause()
		}
	})
}

// ==============================
// REANUDAR MEDIA
// Solo reanuda los elementos que estaban reproduciéndose antes del bloqueo.
// No reanuda elementos que el usuario había pausado manualmente.
// ==============================
function reanudarMedia() {
	mediaReproduciendo.forEach((el) => {
		// Verifica que el elemento siga en el DOM antes de reanudar
		if (document.contains(el)) {
			el.play().catch(() => {}) // play() puede ser rechazado por autoplay policy
		}
	})
	mediaReproduciendo = []
}

// ==============================
// MUTATIONOBSERVER — repausador automático
// YouTube a veces reanuda el video automáticamente después de eventos del DOM.
// Este observer vigila cambios y repausará cualquier video que intente reproducirse
// mientras el blocker esté activo.
// ==============================
function iniciarObserverMedia() {
	if (mediaObserver) mediaObserver.disconnect()

	mediaObserver = new MutationObserver(() => {
		if (!blocker.classList.contains('visible')) return
		document.querySelectorAll('video, audio').forEach((el) => {
			if (!el.paused) el.pause()
		})
	})

	// Observa solo atributos de video/audio, no todo el DOM
	// Evita miles de callbacks por segundo en SPAs como YouTube
	document.querySelectorAll('video, audio').forEach((el) => {
		mediaObserver.observe(el, {
			attributes: true,
			attributeFilter: ['paused'],
		})
	})

	// También observa si se agregan nuevos elementos video/audio al DOM
	mediaObserver.observe(document.documentElement, {
		childList: true,
		subtree:   true,
	})
}

function detenerObserverMedia() {
	if (mediaObserver) {
		mediaObserver.disconnect()
		mediaObserver = null
	}
}

// ==============================
// FORMATO TIEMPO MM:SS
// ==============================
function actualizarTiempo(el, segundos) {
	const min = Math.floor(segundos / 60).toString().padStart(2, '0')
	const seg = (segundos % 60).toString().padStart(2, '0')
	el.textContent = `${min}:${seg}`
}

// ==============================
// TECLA ESC — cierra TODOS los blockers
// En vez de solo cerrar este, avisa al background.
// El background manda 'inactivo' a todas las tabs simultáneamente.
// ==============================
document.addEventListener('keydown', (e) => {
	if (e.key === 'Escape' && blocker.classList.contains('visible')) {
		// Desactiva localmente de inmediato para respuesta instantánea
		desactivarBlocker()
		// Avisa al background para que detenga el timer y notifique todas las tabs
		// Usa un pequeño retry por si el service worker estaba dormido
		const mandarDetener = () => {
			chrome.runtime.sendMessage({ tipo: 'detener' }).catch(() => {
				// Si falló (SW dormido), intenta una vez más tras 300ms
				setTimeout(() => {
					chrome.runtime.sendMessage({ tipo: 'detener' }).catch(() => {})
				}, 300)
			})
		}
		mandarDetener()
	}
})
