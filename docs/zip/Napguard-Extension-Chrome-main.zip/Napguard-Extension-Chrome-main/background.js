// ==============================
// BACKGROUND.JS — Service Worker
// Maneja el estado global y el timer completo de la extensión
//
// ESTRATEGIA DE TIMER:
// No usamos chrome.alarms para el tick segundo a segundo porque
// Manifest V3 tiene un mínimo de 0.5 minutos por alarma.
// En su lugar guardamos el TIMESTAMP de cuando termina el ciclo
// y usamos setInterval normal + una alarm de keepalive cada 0.5 min
// para evitar que el service worker se duerma.
// ==============================

// ==============================
// INSTALACIÓN — estado inicial
// ==============================
chrome.runtime.onInstalled.addListener(() => {
	chrome.storage.local.set({
		estado:            'inactivo',
		concentracion:     25,
		descanso:          5,
		ciclosTotales:     2,
		cicloActual:       0,
		personaje:         null,
		modoOscuro:        false,
		configBlocker: {
			colorFondo:     '#000000',
			difuminado:     75,
			movimiento:     'ninguno',
			tipoMovimiento: 'atravesar',
			velocidad:      5,
		},
		segundosRestantes: 0,
		segundosTotales:   0,
		enDescanso:        false,
		tiempoFin:         null, // timestamp ms de cuando termina el ciclo actual
	})
})

// ==============================
// INTERVALO LOCAL — tick cada segundo
// setInterval es confiable mientras el SW está activo.
// La alarm 'keepalive' lo reactiva si se durmió.
// ==============================
let tickInterval = null

function iniciarTick() {
	if (tickInterval) clearInterval(tickInterval)

	tickInterval = setInterval(() => {
		chrome.storage.local.get(
			['estado', 'tiempoFin', 'segundosTotales',
			'enDescanso', 'cicloActual', 'ciclosTotales',
			'descanso', 'concentracion', 'personaje', 'configBlocker'],
			(data) => {
				// Solo actúa si hay un timer corriendo
				if (data.estado !== 'concentracion' && data.estado !== 'descanso') return
				if (!data.tiempoFin) return

				const ahora = Date.now()
				const seg   = Math.max(0, Math.round((data.tiempoFin - ahora) / 1000))

				// Actualiza segundosRestantes en storage
				chrome.storage.local.set({ segundosRestantes: seg })

				if (seg <= 0) {
					// Ciclo terminado
					terminarCiclo(data)
				} else {
					// Tick normal — notifica popup y tabs
					chrome.runtime.sendMessage({
						tipo:              'tick',
						segundosRestantes: seg,
						segundosTotales:   data.segundosTotales,
						enDescanso:        data.enDescanso,
						cicloActual:       data.cicloActual,
					}).catch(() => {})

					// Actualiza el tiempo visible en el blocker
					if (data.enDescanso) {
						notificarTabs({ estado: 'tick', segundos: seg })
					}
				}
			}
		)
	}, 1000)
}

function detenerTick() {
	if (tickInterval) {
		clearInterval(tickInterval)
		tickInterval = null
	}
}

// ==============================
// KEEPALIVE — alarm cada 25 segundos
// Reactiva el service worker si se durmió
// Cuando se reactiva reinicia el setInterval del tick
// ==============================
chrome.alarms.create('keepalive', { periodInMinutes: 0.4 })

chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name !== 'keepalive') return

	// Revisa si hay un timer activo y reactiva el tick si es necesario
	chrome.storage.local.get(['estado'], (data) => {
		if (data.estado === 'concentracion' || data.estado === 'descanso') {
			// El SW se despertó — reactiva el intervalo
			iniciarTick()
		}
	})
})

// ==============================
// TERMINAR CICLO
// Se llama cuando el timestamp llegó a 0
// Decide si pasar a descanso, concentración o terminar sesión
// ==============================
function terminarCiclo(data) {
	const { enDescanso, cicloActual, ciclosTotales,
	        descanso, concentracion } = data

	// Lee personaje y configBlocker frescos del storage en este momento
	// para asegurar que usamos los valores más recientes que guardó el popup
	chrome.storage.local.get(['personaje', 'configBlocker'], (fresh) => {
		const personaje     = fresh.personaje     || data.personaje     || null
		const configBlocker = fresh.configBlocker || data.configBlocker || null

	if (!enDescanso) {
		// ── Concentración terminó → arranca descanso ────────
		const nuevoCiclo  = cicloActual + 1
		const segDescanso = descanso * 60
		const nuevoFin    = Date.now() + segDescanso * 1000

		// Escribe el nuevo estado — el tick que ya corre leerá el nuevo tiempoFin
		// en el próximo segundo automáticamente. NO llamamos iniciarTick() aquí
		// porque el intervalo ya existe y duplicarlo causaría ticks dobles.
		chrome.storage.local.set({
			enDescanso:        true,
			cicloActual:       nuevoCiclo,
			segundosRestantes: segDescanso,
			segundosTotales:   segDescanso,
			estado:            'descanso',
			tiempoFin:         nuevoFin,
		})

		chrome.runtime.sendMessage({
			tipo:              'cambioFase',
			enDescanso:        true,
			cicloActual:       nuevoCiclo,
			segundosRestantes: segDescanso,
			segundosTotales:   segDescanso,
		}).catch(() => {})

		notificarTabs({
			estado:           'descanso',
			personaje,
			segundosDescanso: segDescanso,
			configBlocker,
		})

	} else {
		// ── Descanso terminó ─────────────────────────────────
		if (cicloActual >= ciclosTotales) {
			// ── Sesión completada ────────────────────────────
			detenerTick()
			chrome.storage.local.set({
				estado:            'inactivo',
				enDescanso:        false,
				cicloActual:       0,
				segundosRestantes: 0,
				tiempoFin:         null,
			})

			chrome.runtime.sendMessage({ tipo: 'sesionCompletada' }).catch(() => {})
			notificarTabs({ estado: 'inactivo' })

		} else {
			// ── Siguiente ciclo de concentración ─────────────
			const segConcentracion = concentracion * 60
			const nuevoFin         = Date.now() + segConcentracion * 1000

			// Igual que arriba — el tick ya corre, solo actualizamos el storage
			chrome.storage.local.set({
				enDescanso:        false,
				segundosRestantes: segConcentracion,
				segundosTotales:   segConcentracion,
				estado:            'concentracion',
				tiempoFin:         nuevoFin,
			})

			chrome.runtime.sendMessage({
				tipo:              'cambioFase',
				enDescanso:        false,
				cicloActual:       cicloActual,
				segundosRestantes: segConcentracion,
				segundosTotales:   segConcentracion,
			}).catch(() => {})

			notificarTabs({ estado: 'inactivo' })
		}
	}
	}) // cierre del chrome.storage.local.get fresh
}

// ==============================
// MENSAJES DESDE EL POPUP
// ==============================
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

	if (msg.tipo === 'iniciar') {
		const segConcentracion = msg.concentracion * 60
		const tiempoFin        = Date.now() + segConcentracion * 1000

		chrome.storage.local.set({
			estado:            'concentracion',
			concentracion:     msg.concentracion,
			descanso:          msg.descanso,
			ciclosTotales:     msg.ciclosTotales,
			personaje:         msg.personaje,
			configBlocker:     msg.configBlocker,
			cicloActual:       0,
			enDescanso:        false,
			segundosRestantes: segConcentracion,
			segundosTotales:   segConcentracion,
			tiempoFin,
		})

		iniciarTick()
		sendResponse({ ok: true })
	}

	else if (msg.tipo === 'pausar') {
		// Guarda cuánto tiempo quedaba al pausar
		chrome.storage.local.get(['segundosRestantes'], (data) => {
			chrome.storage.local.set({
				estado:    'pausado',
				tiempoFin: null, // limpia el timestamp — no hay countdown activo
			})
		})
		detenerTick()
		sendResponse({ ok: true })
	}

	else if (msg.tipo === 'reanudar') {
		// Recalcula el tiempoFin desde los segundos que quedaban
		chrome.storage.local.get(['segundosRestantes', 'enDescanso'], (data) => {
			const nuevoFin = Date.now() + data.segundosRestantes * 1000
			chrome.storage.local.set({
				estado:    data.enDescanso ? 'descanso' : 'concentracion',
				tiempoFin: nuevoFin,
			})
			iniciarTick()
		})
		sendResponse({ ok: true })
	}

	else if (msg.tipo === 'detener') {
		detenerTick()
		chrome.storage.local.set({
			estado:            'inactivo',
			enDescanso:        false,
			cicloActual:       0,
			segundosRestantes: 0,
			segundosTotales:   0,
			tiempoFin:         null,
		})
		// Notifica dos veces con pequeño delay para asegurar que llegue
		// a tabs que puedan estar en medio de una carga
		notificarTabs({ estado: 'inactivo' })
		setTimeout(() => notificarTabs({ estado: 'inactivo' }), 400)
		sendResponse({ ok: true })
	}

	else if (msg.tipo === 'skip') {
		// Salta directo al descanso desde cualquier fase.
		// Detiene el tick actual — terminarCiclo arrancará el nuevo internamente
		// via el storage update. El tick se reinicia solo con el keepalive o
		// llamando iniciarTick() UNA SOLA VEZ después del set del storage.
		detenerTick()
		chrome.storage.local.get(
			['descanso', 'personaje', 'configBlocker',
			'cicloActual', 'ciclosTotales', 'concentracion'],
			(data) => {
				// Usa los valores del storage — si el popup los guardó ya están ahí.
				// Si no se configuró nada, usa los defaults del onInstalled.
				terminarCiclo({
					enDescanso:    false,
					cicloActual:   data.cicloActual   || 0,
					ciclosTotales: data.ciclosTotales || 2,
					descanso:      data.descanso      || 5,
					concentracion: data.concentracion || 25,
					personaje:     data.personaje     || null,
					configBlocker: data.configBlocker || null,
				})
				// Inicia el tick UNA sola vez después de que terminarCiclo
				// ya escribió el nuevo tiempoFin en storage
				setTimeout(() => iniciarTick(), 100)
			}
		)
		sendResponse({ ok: true })
	}

	else if (msg.tipo === 'getEstado') {
		chrome.storage.local.get(
			['estado', 'segundosRestantes', 'segundosTotales',
			 'enDescanso', 'cicloActual', 'ciclosTotales',
			 'concentracion', 'descanso', 'personaje',
			 'modoOscuro', 'configBlocker'],
			(data) => sendResponse(data)
		)
		return true // necesario para respuesta asíncrona
	}

	return true
})

// ==============================
// NOTIFICAR TABS
// Manda un mensaje a content.js en todas las tabs activas.
// Si sendMessage falla (content script no listo todavía),
// usa executeScript como fallback para actuar directamente.
// Ignora tabs del sistema donde no hay content script.
// ==============================
function notificarTabs(payload) {
	chrome.tabs.query({}, (tabs) => {
		tabs.forEach((tab) => {
			if (!tab.url) return
			if (tab.url.startsWith('chrome://')) return
			if (tab.url.startsWith('chrome-extension://')) return
			if (tab.url.startsWith('about:')) return
			if (tab.url.startsWith('edge://')) return

			// Intenta sendMessage primero — el content script lo recibe si está listo
			chrome.tabs.sendMessage(tab.id, payload).catch(() => {
				// Fallback — content script no estaba listo todavía.
				// executeScript inyecta código directamente con permisos del background.
				if (payload.estado === 'descanso') {
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						func: activarBlockerRemoto,
						args: [],
					}).catch(() => {})
				} else if (payload.estado === 'inactivo') {
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						func: desactivarBlockerRemoto,
						args: [],
					}).catch(() => {})
				}
			})
		})
	})
}

// ==============================
// FUNCIONES REMOTAS — inyectadas via executeScript en la tab
// Son funciones puras sin referencias externas porque se serializan.
// Solo actúan si el blocker ya existe en el DOM (puesto por content.js).
// ==============================
function activarBlockerRemoto() {
	const b = document.getElementById('ng-blocker')
	if (b) b.classList.add('visible')
}

function desactivarBlockerRemoto() {
	const b = document.getElementById('ng-blocker')
	if (b) b.classList.remove('visible')
}

// ==============================
// TAB DORMIDA REACTIVADA — onActivated
// Cuando el usuario hace clic en una tab en reposo (discarded),
// Chrome la recarga y el content script verifica el estado por su cuenta.
// Este listener es el seguro extra para tabs que ya estaban cargadas.
// ==============================
chrome.tabs.onActivated.addListener((activeInfo) => {
	chrome.storage.local.get(
		['estado', 'segundosRestantes', 'personaje', 'configBlocker'],
		(data) => {
			if (data.estado !== 'descanso') return

			chrome.tabs.sendMessage(activeInfo.tabId, {
				estado:           'descanso',
				personaje:        data.personaje,
				segundosDescanso: data.segundosRestantes,
				configBlocker:    data.configBlocker,
			}).catch(() => {})
		}
	)
})
