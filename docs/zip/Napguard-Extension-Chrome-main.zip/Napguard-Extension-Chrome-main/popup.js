// ==============================
// VARIABLES GLOBALES
// Reutilizadas de timer.js
// ==============================
let concentracion = 25;
let descanso = 5;
let ciclosTotales = 2;
let personaje = null;
let modoOscuro = false;

let cicloActual = 0;
let enDescanso = false;
let corriendo = false;
let intervalo = null;
let segundosRestantes = 0;
let segundosTotales = 0;
let tiempoInicio = null;

// Tipo de GIF activo — reutilizado de timer.js
let tipoGif = "gifs";
let timerBusqueda = null;

// ==============================
// CONFIG BLOCKER
// Nuevo — equivalente a configBlocker de timer.js
// Pero sin posición, sin pantalla completa, sin texto personalizado
// Solo fondo y movimiento
// ==============================
let configBlocker = {
	colorFondo: '#000000',
	difuminado: 75,
	movimiento: 'ninguno',
	tipoMovimiento: 'atravesar',
	velocidad: 5,
};
let configTemporal = { ...configBlocker };

// Imágenes por categoría — reutilizadas de timer.js imagenesPorCategoria
// NOTA: rutas apuntan a images de la extensión
const imagenesPorCategoria = {
	animales: [
		{ nombre: "Gato", archivo: "images/animales/gato.png" },
		{ nombre: "Perro", archivo: "images/animales/perro.png" },
		{ nombre: "Capibara", archivo: "images/animales/capibara.png" },
		{ nombre: "Conejo", archivo: "images/animales/conejo.png" },
		{ nombre: "Pato", archivo: "images/animales/pato.png" },
		{ nombre: "Castor", archivo: "images/animales/castor.png" },
	],
	anime: [
		{ nombre: "Goku", archivo: "images/anime/goku.webp" },
		{ nombre: "Luffy", archivo: "images/anime/luffy.webp" },
		{ nombre: "Naruto", archivo: "images/anime/naruto.webp" },
		{ nombre: "Itadori", archivo: "images/anime/itadori.webp" },
		{ nombre: "Izuku", archivo: "images/anime/izuku.png" },
		{ nombre: "Ichigo", archivo: "images/anime/ichigo.webp" },
	],
	futbol: [
		{ nombre: "Messi", archivo: "images/futbol/messi.png" },
		{ nombre: "Cristiano", archivo: "images/futbol/cristiano.png" },
		{ nombre: "Neymar", archivo: "images/futbol/neymarJr.png" },
		{ nombre: "Maradona", archivo: "images/futbol/maradona.png" },
		{ nombre: "Pelé", archivo: "images/futbol/pele.webp" },
		{ nombre: "Johan", archivo: "images/futbol/johan.webp" },
	],
};

// ==============================
// REFERENCIAS AL DOM
// Mismas de timer.js pero con IDs del popup.html
// ==============================
const sliderConcentracion = document.getElementById("sliderConcentracion");
const sliderDescanso = document.getElementById("sliderDescanso");
const sliderCiclos = document.getElementById("sliderCiclos");
const valConcentracion = document.getElementById("valConcentracion");
const valDescanso = document.getElementById("valDescanso");
const valCiclos = document.getElementById("valCiclos");
const totalSesion = document.getElementById("totalSesion");

const vistaSettings = document.getElementById("vistaSettings");
const vistaTimer = document.getElementById("vistaTimer");

const estadoActual = document.getElementById("estadoActual");
const ciclosRow = document.getElementById("ciclosRow");
const sesionTag = document.getElementById("sesionTag");
const ringProgress = document.getElementById("ringProgress");
const btnIniciarPausar = document.getElementById("btnIniciarPausar");
const btnVolver = document.getElementById("btnVolver");
const btnEmpezar = document.getElementById("btnEmpezar");
const btnModo = document.getElementById("btnModo");
const iconoModo = document.getElementById("iconoModo");

// Tabs — mismos IDs que timer.html
const tabImagenes = document.getElementById("tabImagenes");
const tabGif = document.getElementById("tabGif");
const panelImagenes = document.getElementById("panelImagenes");
const panelGif = document.getElementById("panelGif");

const vistaCategorias = document.getElementById("vistaCategorias");
const vistaImagenesCat = document.getElementById("vistaImagenesCat");
const imagenesGrid = document.getElementById("imagenesGrid");
const tituloCat = document.getElementById("tituloCat");
const btnVolverCategorias = document.getElementById("btnVolverCategorias");

const inputBuscarGif = document.getElementById("inputBuscarGif");
const gifGrid = document.getElementById("gifGrid");
const btnTabGif = document.getElementById("btnTabGif");
const btnTabSticker = document.getElementById("btnTabSticker");

// ==============================
// REFERENCIAS DOM — vistaConfig
// Nuevo — equivalente a vistaConfig de timer.js
// ==============================
const vistaConfig       = document.getElementById("vistaConfig");
const btnOpciones       = document.getElementById("btnOpciones");
const btnVolverConfig   = document.getElementById("btnVolverConfig");
const btnAceptarConfig  = document.getElementById("btnAceptarConfig");
const btnCancelarConfig = document.getElementById("btnCancelarConfig");
const colorFondo        = document.getElementById("colorFondo");
const sliderDifuminado  = document.getElementById("sliderDifuminado");
const valDifuminado     = document.getElementById("valDifuminado");
const sliderVelocidad   = document.getElementById("sliderVelocidad");
const valVelocidad      = document.getElementById("valVelocidad");
const movimientoOpciones = document.getElementById("movimientoOpciones");

// BTN SKIP — solo para testing rápido del blocker
const btnSkip = document.getElementById("btnSkip");

// ==============================
// SINCRONIZAR SLIDERS
// Función reutilizada de timer.js sincronizarSlider
// ==============================
function sincronizarSlider(slider, input, actualizar) {
	slider.addEventListener("input", () => {
		input.value = slider.value;
		actualizar(parseInt(slider.value));
		calcularTotal();
	});

	input.addEventListener("change", () => {
		let valor = parseInt(input.value);
		if (isNaN(valor)) valor = parseInt(slider.min);
		if (valor < parseInt(slider.min)) valor = parseInt(slider.min);
		if (valor > parseInt(slider.max)) valor = parseInt(slider.max);
		slider.value = valor;
		input.value = valor;
		actualizar(valor);
		calcularTotal();
	});
}

sincronizarSlider(sliderConcentracion, valConcentracion, (v) => {
	concentracion = v;
});
sincronizarSlider(sliderDescanso, valDescanso, (v) => {
	descanso = v;
});
sincronizarSlider(sliderCiclos, valCiclos, (v) => {
	ciclosTotales = v;
});

// ==============================
// CALCULAR TOTAL
// Reutilizado de timer.js calcularTotal
// ==============================
function calcularTotal() {
	const totalMinutos = ciclosTotales * (concentracion + descanso);
	const horas = Math.floor(totalMinutos / 60);
	const minutos = totalMinutos % 60;
	let texto = "";
	if (horas > 0) texto += horas + "h ";
	if (minutos > 0) texto += minutos + "min ";
	texto += `(${totalMinutos} min)`;
	totalSesion.textContent = texto;
}

// ==============================
// MODO CLARO / OSCURO
// Reutilizado de timer.js toggleModo
// Reemplaza: document.body.classList → directo
// Reemplaza: window.api.guardarConfig → chrome.storage.local.set
// ==============================
btnModo.addEventListener("click", () => {
	modoOscuro = !modoOscuro;
	document.body.classList.toggle("dark", modoOscuro);
	iconoModo.textContent = modoOscuro ? "☀️" : "🌙";
	chrome.storage.local.set({ modoOscuro });
});

// ==============================
// TABS DISEÑO DE DESCANSO
// Reutilizado de timer.js cambiarTab
// ==============================
function cambiarTab(tabActivo, panelActivo) {
	[tabImagenes, tabGif].forEach((t) => t.classList.remove("active"));
	[panelImagenes, panelGif].forEach((p) => p.classList.add("oculto"));
	tabActivo.classList.add("active");
	panelActivo.classList.remove("oculto");
}

tabImagenes.addEventListener("click", () =>
	cambiarTab(tabImagenes, panelImagenes),
);
tabGif.addEventListener("click", () => cambiarTab(tabGif, panelGif));

// ==============================
// CATEGORÍAS E IMÁGENES
// Reutilizado de timer.js mostrarCategoria
// Diferencia: chrome.runtime.getURL para rutas de assets
// ==============================
document.querySelectorAll(".categoriaOpt").forEach((cat) => {
	cat.addEventListener("click", () => {
		tituloCat.textContent = cat.querySelectorAll("span")[1].textContent;
		vistaCategorias.classList.add("oculto");
		vistaImagenesCat.classList.remove("oculto");
		mostrarCategoria(cat.dataset.categoria);
	});
});

btnVolverCategorias.addEventListener("click", () => {
	vistaImagenesCat.classList.add("oculto");
	vistaCategorias.classList.remove("oculto");
});

function mostrarCategoria(categoria) {
	const imagenes = imagenesPorCategoria[categoria] || [];
	imagenesGrid.innerHTML = "";

	if (imagenes.length === 0) {
		imagenesGrid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:1rem;font-size:7px;color:var(--textoSecundario)">Próximamente</div>`;
		return;
	}

	imagenes.forEach((img) => {
		const div = document.createElement("div");
		div.classList.add("imagenOpt");
		div.dataset.archivo = img.archivo;

		// chrome.runtime.getURL reemplaza la ruta relativa de Electron
		const url = chrome.runtime.getURL(img.archivo);

		div.innerHTML = `
		<img src="${url}" alt="${img.nombre}">
		<span>${img.nombre}</span>
		`;

		if (personaje === img.archivo) div.classList.add("selected");

		div.addEventListener("click", () => {
		imagenesGrid
			.querySelectorAll(".imagenOpt")
			.forEach((o) => o.classList.remove("selected"));
		div.classList.add("selected");
		personaje = img.archivo;
		// Guarda en storage para que content.js lo lea
		chrome.storage.local.set({ personaje });
		});

		imagenesGrid.appendChild(div);
	});
}

// ==============================
// GIF / STICKER
// Reutilizado de timer.js buscarGif
// Diferencia: fetch directo en vez de window.api.buscarGiphy
// ==============================
const GIPHY_KEY = "1q8GrEJgcFFbrUeu8qJGRQE5XgPAwAe6";

btnTabGif.addEventListener("click", () => {
	tipoGif = "gifs";
	btnTabSticker.classList.remove("active");
	btnTabGif.classList.add("active");
	if (inputBuscarGif.value.trim()) buscarGif(inputBuscarGif.value.trim());
});

btnTabSticker.addEventListener("click", () => {
	tipoGif = "stickers";
	btnTabGif.classList.remove("active");
	btnTabSticker.classList.add("active");
	if (inputBuscarGif.value.trim()) buscarGif(inputBuscarGif.value.trim());
});

inputBuscarGif.addEventListener("input", () => {
	clearTimeout(timerBusqueda);
	const query = inputBuscarGif.value.trim();

	if (!query) {
		gifGrid.innerHTML = `
		<div class="gifPlaceholder">
			<span>🔍</span>
			<span>Escribe algo para buscar</span>
		</div>`;
		return;
	}

	timerBusqueda = setTimeout(() => buscarGif(query), 600);
});

async function buscarGif(query) {
	gifGrid.innerHTML = `
		<div class="gifPlaceholder">
		<span>⏳</span>
		<span>Buscando...</span>
		</div>`;

	try {
		// fetch directo reemplaza window.api.buscarGiphy de Electron
		const endpoint = tipoGif === "gifs" ? "gifs" : "stickers";
		const url = `https://api.giphy.com/v1/${endpoint}/search?api_key=${GIPHY_KEY}&q=${encodeURIComponent(query)}&limit=12&rating=g`;
		const res = await fetch(url);
		const datos = await res.json();

		if (datos.data.length === 0) {
		gifGrid.innerHTML = `<div class="gifPlaceholder"><span>😢</span><span>Sin resultados</span></div>`;
		return;
		}

		gifGrid.innerHTML = "";
		datos.data.forEach((gif) => {
		const img = document.createElement("img");
		img.classList.add("gifItem");
		img.src = gif.images.fixed_height_small.url;
		img.alt = gif.title;

		img.addEventListener("click", () => {
			gifGrid
			.querySelectorAll(".gifItem")
			.forEach((g) => g.classList.remove("selected"));
			img.classList.add("selected");
			// URL original del gif — igual que timer.js
			personaje = gif.images.original.url;
			chrome.storage.local.set({ personaje });
		});

		gifGrid.appendChild(img);
		});
	} catch (e) {
		gifGrid.innerHTML = `<div class="gifPlaceholder"><span>📶</span><span>Error de conexión</span></div>`;
	}
}

// ==============================
// NAVEGACIÓN SETTINGS → TIMER
// Reutilizado de timer.js btnEmpezar listener
// Reemplaza: window.api.guardarConfig → chrome.storage.local.set
// ==============================
btnEmpezar.addEventListener("click", () => {
	// Guarda config en chrome.storage
	chrome.storage.local.set({
		concentracion,
		descanso,
		ciclosTotales,
		personaje,
		configBlocker,
	});

	vistaSettings.classList.add("oculto");
	vistaTimer.classList.remove("oculto");

	generarCiclos();
	sesionTag.textContent = totalSesion.textContent;

	// Estado inicial del reloj antes de que llegue el primer tick
	segundosRestantes = concentracion * 60;
	segundosTotales   = concentracion * 60;
	corriendo         = false;
	enDescanso        = false;
	cicloActual       = 0;

	actualizarReloj();
	estadoActual.textContent = "Concentración";

	// Le dice al background que arranque el timer
	// El background crea la alarm 'tick' y maneja todo desde ahí
	chrome.runtime.sendMessage({
		tipo:          'iniciar',
		concentracion,
		descanso,
		ciclosTotales,
		personaje,
		configBlocker,
	});

	corriendo = true;
	btnIniciarPausar.textContent = "⏸ PAUSA";
});

// Volver — reutilizado de timer.js btnSettings listener
btnVolver.addEventListener("click", () => {
	// Le dice al background que detenga el timer y limpie el estado
	chrome.runtime.sendMessage({ tipo: 'detener' });

	corriendo  = false;
	enDescanso = false;
	cicloActual = 0;

	vistaTimer.classList.add("oculto");
	vistaSettings.classList.remove("oculto");

	btnIniciarPausar.textContent = "▶ INICIAR";
});

// ==============================
// TIMER — INICIAR / PAUSAR
// Ya no maneja el countdown aquí — solo le avisa al background
// El background es quien tiene el setInterval real (chrome.alarms)
// ==============================
btnIniciarPausar.addEventListener("click", () => {
	if (!corriendo) {
		// Reanudar — el background reactiva el tick
		chrome.runtime.sendMessage({ tipo: 'reanudar' });
		corriendo = true;
		btnIniciarPausar.textContent = "⏸ PAUSA";
	} else {
		// Pausar — el background cancela el tick pero guarda el tiempo
		chrome.runtime.sendMessage({ tipo: 'pausar' });
		corriendo = false;
		btnIniciarPausar.textContent = "▶ INICIAR";
	}
});

// terminarCiclo fue eliminado del popup — ahora vive en background.js
// El background es el único dueño del tiempo y los ciclos

// ==============================
// CICLOS — cuadraditos
// Reutilizados de timer.js generarCiclos / marcarCiclo
// ==============================
function generarCiclos() {
	ciclosRow.innerHTML = "";
	for (let i = 0; i < ciclosTotales; i++) {
		const c = document.createElement("div");
		c.classList.add("cicloCuadrado");
		c.id = `ciclo-${i}`;
		ciclosRow.appendChild(c);
	}
}

function marcarCiclo(numero) {
	const c = document.getElementById(`ciclo-${numero - 1}`);
	if (c) c.classList.add("done");
}

// ==============================
// RELOJ CIRCULAR
// Reutilizado de timer.js actualizarReloj
// ==============================
function actualizarReloj() {
	const progreso = 1 - segundosRestantes / segundosTotales;
	const circunferencia = 502.6;
	const offset = circunferencia - progreso * circunferencia;
	ringProgress.style.strokeDashoffset = offset;
}

// notificarTabs fue eliminado del popup
// El background.js es quien notifica las tabs directamente

// ==============================
// VISTA CONFIG — abrir / cerrar
// Equivalente a btnOpciones / btnVolverConfig de timer.js
// ==============================

// Abre vistaConfig desde vistaSettings
btnOpciones.addEventListener("click", () => {
	// Guarda copia temporal por si el usuario cancela
	configTemporal = { ...configBlocker };

	// Carga los valores guardados en los controles visuales
	colorFondo.value        = configBlocker.colorFondo;
	sliderDifuminado.value  = configBlocker.difuminado;
	valDifuminado.textContent = `${configBlocker.difuminado}%`;
	sliderVelocidad.value   = configBlocker.velocidad;
	valVelocidad.textContent = configBlocker.velocidad;

	// Marca la opción de movimiento activa
	document.querySelectorAll(".movimientoOpt").forEach((opt) => {
		opt.classList.toggle("selected", opt.dataset.mov === configBlocker.movimiento);
	});

	// Muestra u oculta mini opciones según el movimiento guardado
	if (configBlocker.movimiento !== "ninguno") {
		movimientoOpciones.classList.remove("oculto");
	} else {
		movimientoOpciones.classList.add("oculto");
	}

	// Marca el tipo de movimiento activo
	document.querySelectorAll(".movimientoTipo").forEach((t) => {
		t.classList.toggle("selected", t.dataset.tipo === configBlocker.tipoMovimiento);
	});

	vistaSettings.classList.add("oculto");
	vistaConfig.classList.remove("oculto");
});

// Volver sin guardar — restaura la copia temporal
btnVolverConfig.addEventListener("click", () => {
	configBlocker = { ...configTemporal };
	vistaConfig.classList.add("oculto");
	vistaSettings.classList.remove("oculto");
});

// Cancelar — igual que volver
btnCancelarConfig.addEventListener("click", () => {
	configBlocker = { ...configTemporal };
	vistaConfig.classList.add("oculto");
	vistaSettings.classList.remove("oculto");
});

// Aceptar — guarda los valores actuales de los controles
btnAceptarConfig.addEventListener("click", () => {
	const movSeleccionado = document.querySelector(".movimientoOpt.selected");
	const tipoSeleccionado = document.querySelector(".movimientoTipo.selected");

	configBlocker = {
		colorFondo:     colorFondo.value,
		difuminado:     parseInt(sliderDifuminado.value),
		movimiento:     movSeleccionado ? movSeleccionado.dataset.mov : "ninguno",
		tipoMovimiento: tipoSeleccionado ? tipoSeleccionado.dataset.tipo : "atravesar",
		velocidad:      parseInt(sliderVelocidad.value),
	};

	// Persiste en chrome.storage para que no se pierda al reabrir el popup
	chrome.storage.local.set({ configBlocker });

	vistaConfig.classList.add("oculto");
	vistaSettings.classList.remove("oculto");
});

// Actualiza el label de opacidad en tiempo real mientras mueve el slider
sliderDifuminado.addEventListener("input", () => {
	valDifuminado.textContent = `${sliderDifuminado.value}%`;
});

// Actualiza el label de velocidad en tiempo real
sliderVelocidad.addEventListener("input", () => {
	valVelocidad.textContent = sliderVelocidad.value;
});

// Selección de movimiento — muestra u oculta mini opciones
document.querySelectorAll(".movimientoOpt").forEach((opt) => {
	opt.addEventListener("click", () => {
		document.querySelectorAll(".movimientoOpt").forEach((o) => o.classList.remove("selected"));
		opt.classList.add("selected");

		if (opt.dataset.mov === "ninguno") {
			movimientoOpciones.classList.add("oculto");
		} else {
			movimientoOpciones.classList.remove("oculto");
		}
	});
});

// Selección de tipo de movimiento
document.querySelectorAll(".movimientoTipo").forEach((tipo) => {
	tipo.addEventListener("click", () => {
		document.querySelectorAll(".movimientoTipo").forEach((t) => t.classList.remove("selected"));
		tipo.classList.add("selected");
	});
});

// ==============================
// BTN SKIP — testing rápido del blocker
// Guarda la config actual antes de mandar el skip
// para que el background tenga personaje y configBlocker correctos.
// ELIMINAR antes de publicar la extensión
// ==============================
btnSkip.addEventListener("click", () => {
	// Primero guarda el estado actual del popup en storage
	chrome.storage.local.set({
		personaje,
		configBlocker,
		concentracion,
		descanso,
		ciclosTotales,
	}, () => {
		// Luego manda el skip — ahora el background leerá los valores correctos
		chrome.runtime.sendMessage({ tipo: 'skip' })
	})
});

// ==============================
// INICIALIZACIÓN
// Reutilizado de timer.js inicializar
// Reemplaza: window.api.cargarConfig → chrome.storage.local.get
// ==============================
chrome.storage.local.get(
	["concentracion", "descanso", "ciclosTotales", "personaje", "modoOscuro", "configBlocker"],
	(config) => {
		if (config.concentracion) {
		concentracion = config.concentracion;
		descanso = config.descanso;
		ciclosTotales = config.ciclosTotales;
		personaje = config.personaje || null;
		modoOscuro = config.modoOscuro || false;
		}

		// Carga configBlocker guardado — si no existe usa los valores por defecto
		if (config.configBlocker) {
			configBlocker = config.configBlocker;
		}

		document.body.classList.toggle("dark", modoOscuro);
		iconoModo.textContent = modoOscuro ? "☀️" : "🌙";

		sliderConcentracion.value = concentracion;
		sliderDescanso.value = descanso;
		sliderCiclos.value = ciclosTotales;
		valConcentracion.value = concentracion;
		valDescanso.value = descanso;
		valCiclos.value = ciclosTotales;

		calcularTotal();

		// ── Sincroniza el popup con el estado actual del background ──
		// Por si el timer estaba corriendo cuando se cerró el popup
		chrome.runtime.sendMessage({ tipo: 'getEstado' }, (estado) => {
			if (!estado) return

			concentracion  = estado.concentracion  || concentracion
			descanso       = estado.descanso        || descanso
			ciclosTotales  = estado.ciclosTotales   || ciclosTotales
			personaje      = estado.personaje       || null
			modoOscuro     = estado.modoOscuro      || false
			configBlocker  = estado.configBlocker   || configBlocker

			segundosRestantes = estado.segundosRestantes || 0
			segundosTotales   = estado.segundosTotales   || 0
			cicloActual       = estado.cicloActual       || 0
			enDescanso        = estado.enDescanso        || false

			const estadoActivo = estado.estado

			// Si el timer estaba corriendo, muestra la vista timer
			if (estadoActivo === 'concentracion' || estadoActivo === 'descanso' || estadoActivo === 'pausado') {
				vistaSettings.classList.add('oculto')
				vistaTimer.classList.remove('oculto')

				generarCiclos()
				// Marca los ciclos ya completados
				for (let i = 1; i <= cicloActual; i++) marcarCiclo(i)

				estadoActual.textContent = enDescanso ? 'Descanso' : 'Concentración'
				sesionTag.textContent    = totalSesion.textContent
				actualizarReloj()

				corriendo = (estadoActivo !== 'pausado')
				btnIniciarPausar.textContent = corriendo ? '⏸ PAUSA' : '▶ INICIAR'
			}
		})
	},
);

// ==============================
// ESCUCHAR MENSAJES DEL BACKGROUND
// El background manda updates cada segundo mientras el popup está abierto
// Esto permite que el reloj se vea moviéndose en tiempo real
// ==============================
chrome.runtime.onMessage.addListener((msg) => {

	if (msg.tipo === 'tick') {
		// Actualiza el tiempo y el reloj circular cada segundo
		segundosRestantes = msg.segundosRestantes
		segundosTotales   = msg.segundosTotales
		enDescanso        = msg.enDescanso
		cicloActual       = msg.cicloActual
		actualizarReloj()
	}

	else if (msg.tipo === 'cambioFase') {
		// El background cambió de concentración a descanso o viceversa
		segundosRestantes = msg.segundosRestantes
		segundosTotales   = msg.segundosTotales
		enDescanso        = msg.enDescanso
		cicloActual       = msg.cicloActual

		estadoActual.textContent = enDescanso ? 'Descanso' : 'Concentración'
		marcarCiclo(cicloActual)
		actualizarReloj()
	}

	else if (msg.tipo === 'sesionCompletada') {
		// Todos los ciclos terminaron
		estadoActual.textContent = '¡LOGRADO!'
		corriendo = false
		btnIniciarPausar.textContent = '▶ INICIAR'
	}
})
